//dlgchatproc.h
#pragma once

INT_PTR CALLBACK DlgChatProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);