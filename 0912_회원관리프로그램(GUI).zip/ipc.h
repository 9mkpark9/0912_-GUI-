//ipc.h
#pragma once

BOOL ipc_Connect(HWND hDlg, const TCHAR* target_name);
int ipc_SendData(HWND hDlg, PACKET pack);
BOOL ipc_AddFriend(HWND hDlg, const TCHAR* target_name);

void ipc_TargetHandle(HWND htargt);