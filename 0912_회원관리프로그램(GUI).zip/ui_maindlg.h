//ui_maindlg.h
#pragma once

void ui_MainDlg_Init(HWND hDlg);

void ui_MainDlg_GetData(TCHAR* id, int id_size,  TCHAR* pw, int pw_size);
void ui_MadinDlg_SetData(const TCHAR* id, const TCHAR* pw);
