//fio.h
#pragma once

void fio_load(vector<Member*>* pmembers);
void fio_save(const vector<Member*>* pmembers);
