//handler.h
#pragma once

INT_PTR OnInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam);
INT_PTR OnCommand(HWND hDlg, WPARAM wParam, LPARAM lParam);