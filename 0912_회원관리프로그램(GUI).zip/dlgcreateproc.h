//dlgcreateproc.h
#pragma once

INT_PTR CALLBACK DlgCreateProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);
